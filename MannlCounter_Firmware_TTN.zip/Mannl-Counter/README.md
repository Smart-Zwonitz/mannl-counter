# TinyLoRa Firmware

Example Sensor Node Firmware with a BMP/E280 or SHT21 Sensor. Used Sensor has to be set via #define in the src/secconfig.h (HAS_BME280 or HAS_SHT21). Please change the values in src/secconfig.h to your Keys from https://console.thethingsnetwork.org. Device has to be set to ABP Mode and the Frame Counter has to be set to 16 Bit.

For a complete explanation of the Parameters possible in the secconfig.h see https://www.ttgw.de/sites/tinylora/20-firmware

The code also supports the RFM69W wireless module instead of the RFM95W LoRa module. For this purpose you need a receiver. Example code for a receiver in python (tested on a Raspberry Pi, RFM69 connected via SPI) can be found at https://www.seiichiro0185.org/git/IOT/sensord

Project was created using PlatformIO Atmel-AVR Framework

## Decoder for the TTN Application

take a look in ttn folder

## License
The firmware-code in this repository is licensed under the 3-clause BSD License (see LICENSE-File)
